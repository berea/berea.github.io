
//----------------------------------------------
//Used for Berea College Hobsons Connect to populate various fields
//Created by Jacob Patton (C) 2017,2018
//----------------------------------------------



//--------------
//Recruitment And Outreach Functions
//--------------

//None currently. 