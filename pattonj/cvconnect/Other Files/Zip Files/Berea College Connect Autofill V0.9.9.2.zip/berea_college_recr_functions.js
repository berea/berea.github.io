
//----------------------------------------------
//Used for Berea College Hobsons Connect to populate various fields
//Created by Jacob Patton (C) 2017,2018
//----------------------------------------------



//--------------
//Recruitment And Outreach Functions
//--------------

//None currently. 

/* var test;

const booFeelsTable = {
  "HUNGRY": "WANTS FOOD",
  "SAD": "CRYING",
  "HAPPY": "LAUGHING"
};
 



function howIsBoo(state){
	if (booFeelsTable[state]  !== undefined){
  	test = booFeelsTable[state];
  }
  else{
    test = "asleep";
  }
  console.log(test);
}
//var test = howIsBoo("SAD");

howIsBoo("SAD"); */